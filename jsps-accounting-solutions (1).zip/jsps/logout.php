<?php
/**
 * logout.php — Destroys the session and redirects to home.
 */

require_once __DIR__ . '/bootstrap.php';

// Destroy session
$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params['path'], $params['domain'],
        $params['secure'], $params['httponly']
    );
}
session_destroy();

header('Location: ' . APP_URL . '/login.php');
exit;
